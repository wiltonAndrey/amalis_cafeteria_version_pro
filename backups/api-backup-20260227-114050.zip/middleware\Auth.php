<?php

require_once __DIR__ . '/../utils/Response.php';

if (!function_exists('auth_issue_csrf_token')) {
  function auth_issue_csrf_token(): string
  {
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
      $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }

    return $_SESSION['csrf_token'];
  }
}

if (!function_exists('auth_requires_csrf')) {
  function auth_requires_csrf(): bool
  {
    return api_env_string('API_ENFORCE_CSRF', '0') === '1';
  }
}

if (!function_exists('auth_validate_csrf_token')) {
  function auth_validate_csrf_token(): bool
  {
    if (!auth_requires_csrf()) {
      return true;
    }

    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
      return true;
    }

    $header = trim((string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    $sessionToken = (string) ($_SESSION['csrf_token'] ?? '');
    if ($header === '' || $sessionToken === '') {
      return false;
    }

    return hash_equals($sessionToken, $header);
  }
}

function require_auth(): array
{
  api_start_session();

  if (empty($_SESSION['admin_id'])) {
    Response::json(['ok' => false, 'error' => 'unauthorized'], 401);
    return ['ok' => false];
  }

  if (!api_verify_origin()) {
    Response::json(['ok' => false, 'error' => 'invalid_origin'], 403);
    return ['ok' => false];
  }

  if (!auth_validate_csrf_token()) {
    Response::json(['ok' => false, 'error' => 'csrf_invalid'], 403);
    return ['ok' => false];
  }

  return [
    'ok' => true,
    'admin' => [
      'id' => $_SESSION['admin_id'],
      'email' => $_SESSION['admin_email'] ?? '',
    ],
    'csrfToken' => auth_issue_csrf_token(),
  ];
}
