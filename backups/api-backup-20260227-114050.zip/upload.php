<?php
require __DIR__ . '/bootstrap.php';

if (!function_exists('upload_slugify')) {
  function upload_slugify(string $value): string
  {
    $normalized = trim($value);
    if ($normalized === '') {
      return 'producto';
    }

    $map = [
      'á' => 'a', 'à' => 'a', 'ä' => 'a', 'â' => 'a', 'ã' => 'a',
      'é' => 'e', 'è' => 'e', 'ë' => 'e', 'ê' => 'e',
      'í' => 'i', 'ì' => 'i', 'ï' => 'i', 'î' => 'i',
      'ó' => 'o', 'ò' => 'o', 'ö' => 'o', 'ô' => 'o', 'õ' => 'o',
      'ú' => 'u', 'ù' => 'u', 'ü' => 'u', 'û' => 'u',
      'ñ' => 'n', 'ç' => 'c',
      'Á' => 'A', 'À' => 'A', 'Ä' => 'A', 'Â' => 'A', 'Ã' => 'A',
      'É' => 'E', 'È' => 'E', 'Ë' => 'E', 'Ê' => 'E',
      'Í' => 'I', 'Ì' => 'I', 'Ï' => 'I', 'Î' => 'I',
      'Ó' => 'O', 'Ò' => 'O', 'Ö' => 'O', 'Ô' => 'O', 'Õ' => 'O',
      'Ú' => 'U', 'Ù' => 'U', 'Ü' => 'U', 'Û' => 'U',
      'Ñ' => 'N', 'Ç' => 'C',
      'Ã¡' => 'a', 'Ã ' => 'a', 'Ã¤' => 'a', 'Ã¢' => 'a', 'Ã£' => 'a',
      'Ã©' => 'e', 'Ã¨' => 'e', 'Ã«' => 'e', 'Ãª' => 'e',
      'Ã­' => 'i', 'Ã¬' => 'i', 'Ã¯' => 'i', 'Ã®' => 'i',
      'Ã³' => 'o', 'Ã²' => 'o', 'Ã¶' => 'o', 'Ã´' => 'o', 'Ãµ' => 'o',
      'Ãº' => 'u', 'Ã¹' => 'u', 'Ã¼' => 'u', 'Ã»' => 'u',
      'Ã±' => 'n', 'Ã§' => 'c',
      'Ã' => 'A', 'Ã€' => 'A', 'Ã„' => 'A', 'Ã‚' => 'A', 'Ãƒ' => 'A',
      'Ã‰' => 'E', 'Ãˆ' => 'E', 'Ã‹' => 'E', 'ÃŠ' => 'E',
      'Ã' => 'I', 'ÃŒ' => 'I', 'Ã' => 'I', 'ÃŽ' => 'I',
      'Ã“' => 'O', 'Ã’' => 'O', 'Ã–' => 'O', 'Ã”' => 'O', 'Ã•' => 'O',
      'Ãš' => 'U', 'Ã™' => 'U', 'Ãœ' => 'U', 'Ã›' => 'U',
      'Ã‘' => 'N', 'Ã‡' => 'C',
    ];
    $normalized = strtr($normalized, $map);

    if (function_exists('iconv')) {
      $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $normalized);
      if (is_string($converted) && $converted !== '') {
        $normalized = $converted;
      }
    }

    $normalized = strtolower($normalized);
    $normalized = preg_replace('/[^a-z0-9]+/', '-', $normalized) ?? '';
    $normalized = trim($normalized, '-');
    return $normalized === '' ? 'producto' : $normalized;
  }
}

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? (php_sapi_name() === 'cli' ? 'POST' : 'GET')));
if ($method !== 'POST') {
  Response::json(['ok' => false, 'error' => 'method_not_allowed'], 405);
  return;
}

$auth = require_auth();
if (empty($auth['ok'])) {
  return;
}

if (!api_require_request_guard('upload_image', 20, 60)) {
  return;
}

if (empty($_FILES['image'])) {
  Response::json(['ok' => false, 'error' => 'missing_file'], 400);
  return;
}

$file = $_FILES['image'];
if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
  Response::json(['ok' => false, 'error' => 'upload_error'], 400);
  return;
}

$maxBytes = 5 * 1024 * 1024;
$size = isset($file['size']) ? (int) $file['size'] : 0;
if ($size <= 0 || $size > $maxBytes) {
  $errorCode = $size > $maxBytes ? 'file_too_large' : 'invalid_file_size';
  $status = $size > $maxBytes ? 413 : 400;
  Response::json(['ok' => false, 'error' => $errorCode], $status);
  return;
}

$allowedMimes = [
  'image/jpeg' => 'jpg',
  'image/png' => 'png',
  'image/webp' => 'webp',
  'image/gif' => 'gif',
];
$allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

$originalName = (string) ($file['name'] ?? '');
$originalExt = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
if ($originalExt !== '' && !in_array($originalExt, $allowedExtensions, true)) {
  Response::json(['ok' => false, 'error' => 'invalid_type'], 415);
  return;
}

$mime = '';
if (!empty($file['tmp_name']) && file_exists($file['tmp_name'])) {
  if (function_exists('finfo_open')) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo) {
      $mime = (string) finfo_file($finfo, $file['tmp_name']);
      finfo_close($finfo);
    }
  } elseif (function_exists('mime_content_type')) {
    $mime = (string) mime_content_type($file['tmp_name']);
  }
}

if ($mime === '' && !empty($file['type'])) {
  $mime = (string) $file['type'];
}

if ($mime === '' || empty($allowedMimes[$mime])) {
  Response::json(['ok' => false, 'error' => 'invalid_type'], 415);
  return;
}

$imageInfo = @getimagesize($file['tmp_name']);
if (!is_array($imageInfo) || empty($imageInfo[0]) || empty($imageInfo[1])) {
  Response::json(['ok' => false, 'error' => 'invalid_image'], 415);
  return;
}

$maxWidth = 6000;
$maxHeight = 6000;
if ((int) $imageInfo[0] > $maxWidth || (int) $imageInfo[1] > $maxHeight) {
  Response::json(['ok' => false, 'error' => 'invalid_dimensions'], 413);
  return;
}

$imagesRoot = realpath(__DIR__ . '/../public/images');
if ($imagesRoot === false) {
  Response::json(['ok' => false, 'error' => 'upload_dir_missing'], 500);
  return;
}

if (!is_writable($imagesRoot)) {
  Response::json(['ok' => false, 'error' => 'upload_dir_not_writable'], 500);
  return;
}

$uploadType = strtolower(trim((string) ($_POST['type'] ?? '')));
$isProductUpload = in_array($uploadType, ['product', 'products'], true);
$targetFolder = $isProductUpload ? 'products' : 'uploads';
$publicUrlPrefix = $isProductUpload ? '/images/products/' : '/images/uploads/';

$uploadDir = $imagesRoot . DIRECTORY_SEPARATOR . $targetFolder;
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
  Response::json(['ok' => false, 'error' => 'upload_dir_failed'], 500);
  return;
}

$resolvedUploadDir = realpath($uploadDir);
if ($resolvedUploadDir === false || strpos($resolvedUploadDir, $imagesRoot) !== 0) {
  Response::json(['ok' => false, 'error' => 'upload_dir_invalid'], 500);
  return;
}

if (!is_writable($resolvedUploadDir)) {
  Response::json(['ok' => false, 'error' => 'upload_dir_not_writable'], 500);
  return;
}

$extension = $allowedMimes[$mime];

if ($isProductUpload) {
  $originalBasename = basename(str_replace('\\', '/', $originalName));
  $nameWithoutExtension = (string) pathinfo($originalBasename, PATHINFO_FILENAME);
  $slugValue = upload_slugify($nameWithoutExtension);
  $filename = $slugValue . '.' . $extension;
  $candidatePath = $resolvedUploadDir . DIRECTORY_SEPARATOR . $filename;
  $counter = 2;
  while (file_exists($candidatePath)) {
    $filename = $slugValue . '-' . $counter . '.' . $extension;
    $candidatePath = $resolvedUploadDir . DIRECTORY_SEPARATOR . $filename;
    $counter++;
  }
} else {
  $filename = bin2hex(random_bytes(12)) . '.' . $extension;
}

$targetPath = $resolvedUploadDir . DIRECTORY_SEPARATOR . $filename;
$moved = false;
if (!empty($file['tmp_name'])) {
  if (is_uploaded_file($file['tmp_name'])) {
    $moved = move_uploaded_file($file['tmp_name'], $targetPath);
  } elseif (php_sapi_name() === 'cli') {
    $moved = rename($file['tmp_name'], $targetPath);
  }
}

if (!$moved) {
  Response::json(['ok' => false, 'error' => 'move_failed'], 500);
  return;
}

@chmod($targetPath, 0644);

Response::json(['ok' => true, 'url' => $publicUrlPrefix . $filename], 201);
