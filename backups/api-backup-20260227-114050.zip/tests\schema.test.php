<?php
require __DIR__ . '/../bootstrap.php';

ob_start();
require __DIR__ . '/../update_schema_alt.php';
require __DIR__ . '/../update_schema_title.php';
require __DIR__ . '/../update_schema_chef_suggestion.php';
require __DIR__ . '/../update_schema_menu_taxonomy.php';
ob_end_clean();

$pdo = get_pdo();
$tables = [
  'menu_categories',
  'menu_products',
  'products',
  'promotion_cards',
  'settings',
  'admins',
  'hero',
  'features',
  'philosophy',
  'testimonials',
];
$placeholders = implode(',', array_fill(0, count($tables), '?'));
$stmt = $pdo->prepare(
  "SELECT table_name
   FROM information_schema.tables
   WHERE table_schema = DATABASE()
     AND table_name IN ($placeholders)"
);
$stmt->execute($tables);
$found = $stmt->fetchAll(PDO::FETCH_COLUMN);

$missing = array_diff($tables, $found);
if ($missing) {
  fwrite(STDERR, "FAIL: missing tables: " . implode(', ', $missing) . "\n");
  exit(1);
}

$columnStmt = $pdo->prepare(
  "SELECT COLUMN_NAME
   FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'menu_products'"
);
$columnStmt->execute();
$columns = $columnStmt->fetchAll(PDO::FETCH_COLUMN);
$requiredColumns = ['alt_text', 'image_title', 'chef_suggestion', 'subcategory'];
$missingColumns = array_diff($requiredColumns, $columns);

if ($missingColumns) {
  fwrite(STDERR, "FAIL: missing columns in menu_products: " . implode(', ', $missingColumns) . "\n");
  exit(1);
}

$categoryColumnStmt = $pdo->prepare(
  "SELECT COLUMN_NAME
   FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'menu_categories'"
);
$categoryColumnStmt->execute();
$categoryColumns = $categoryColumnStmt->fetchAll(PDO::FETCH_COLUMN);
$requiredCategoryColumns = ['active', 'visible_in_menu'];
$missingCategoryColumns = array_diff($requiredCategoryColumns, $categoryColumns);

if ($missingCategoryColumns) {
  fwrite(STDERR, "FAIL: missing columns in menu_categories: " . implode(', ', $missingCategoryColumns) . "\n");
  exit(1);
}

$promoColumnStmt = $pdo->prepare(
  "SELECT COLUMN_NAME
   FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = 'promotion_cards'"
);
$promoColumnStmt->execute();
$promoColumns = $promoColumnStmt->fetchAll(PDO::FETCH_COLUMN);
$requiredPromoColumns = [
  'image_alt',
  'image_title',
  'items',
  'availability_text',
  'cta_label',
  'cta_url',
];
$missingPromoColumns = array_diff($requiredPromoColumns, $promoColumns);

if ($missingPromoColumns) {
  fwrite(STDERR, "FAIL: missing columns in promotion_cards: " . implode(', ', $missingPromoColumns) . "\n");
  exit(1);
}

$indexStmt = $pdo->prepare(
  "SELECT INDEX_NAME
   FROM information_schema.STATISTICS
   WHERE TABLE_SCHEMA = DATABASE()
     AND TABLE_NAME = ?"
);

$requiredIndexesByTable = [
  'menu_products' => ['idx_menu_products_active_category_sort'],
  'menu_categories' => ['idx_menu_categories_visible_sort'],
  'products' => ['idx_products_active_sort'],
  'promotion_cards' => ['idx_promotion_cards_active_sort'],
];

foreach ($requiredIndexesByTable as $table => $requiredIndexes) {
  $indexStmt->execute([$table]);
  $tableIndexes = $indexStmt->fetchAll(PDO::FETCH_COLUMN);
  $missingIndexes = array_diff($requiredIndexes, $tableIndexes);
  if ($missingIndexes) {
    fwrite(STDERR, "FAIL: missing indexes in {$table}: " . implode(', ', $missingIndexes) . "\n");
    exit(1);
  }
}

echo "PASS\n";
