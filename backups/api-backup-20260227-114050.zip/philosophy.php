<?php
require __DIR__ . '/bootstrap.php';

$pdo = get_pdo();

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method === 'POST') {
  $auth = require_auth();
  if (empty($auth['ok'])) {
    return;
  }

  if (!api_require_request_guard('philosophy_write', 30, 60)) {
    return;
  }

  $raw = file_get_contents('php://input');
  $body = json_decode($raw, true);
  $input = array_merge($_POST, is_array($body) ? $body : []);

  $title = Validator::string_trim($input['title'] ?? '');
  $content = Validator::string_trim($input['content'] ?? '');
  $image = Validator::string_trim($input['image'] ?? '');

  if (!Validator::required($title) || !Validator::required($content) || !Validator::required($image)) {
    Response::json(['ok' => false, 'error' => 'missing_fields'], 400);
    return;
  }

  try {
    $row = $pdo->query('SELECT id FROM philosophy ORDER BY id LIMIT 1')->fetch();
    if ($row) {
      $stmt = $pdo->prepare(
        'UPDATE philosophy SET title = ?, content = ?, image = ? WHERE id = ?'
      );
      $stmt->execute([$title, $content, $image, $row['id']]);
    } else {
      $stmt = $pdo->prepare(
        'INSERT INTO philosophy (title, content, image) VALUES (?, ?, ?)'
      );
      $stmt->execute([$title, $content, $image]);
    }

    Response::json(['ok' => true]);
  } catch (Throwable $error) {
    Response::error('db_error', 500, $error);
  }

  return;
}

try {
  $row = $pdo->query(
    'SELECT title, content, image FROM philosophy ORDER BY id LIMIT 1'
  )->fetch();

  if (!$row) {
    api_send_cached_json([
      'title' => '',
      'content' => '',
      'image' => '',
    ], 120);
    return;
  }

  api_send_cached_json([
    'title' => $row['title'],
    'content' => $row['content'],
    'image' => $row['image'],
  ], 120);
} catch (Throwable $error) {
  Response::error('db_error', 500, $error);
}
