<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

ob_start();
require __DIR__ . '/../update_schema_menu_taxonomy.php';
ob_end_clean();

$_SESSION['admin_id'] = 1;

$_POST = [
  'name' => 'Producto Test',
  'price' => 10.50,
  'category' => 'bebidas',
  'subcategory' => 'cafes',
  'description' => 'Desc',
  'ingredients' => ['Harina'],
  'allergens' => ['Gluten'],
  'image' => '/images/sections/editada-01.webp',
];

ob_start();
require __DIR__ . '/../products/create.php';
$json = ob_get_clean();
$data = json_decode($json, true);

if (empty($data['id'])) {
  fwrite(STDERR, "FAIL: missing id\n");
  exit(1);
}

$pdo = get_pdo();
$stmt = $pdo->prepare('SELECT category, subcategory FROM menu_products WHERE id = ? LIMIT 1');
$stmt->execute([(int) $data['id']]);
$row = $stmt->fetch();

if (!$row) {
  fwrite(STDERR, "FAIL: created row not found\n");
  exit(1);
}

if (($row['category'] ?? '') !== 'bebidas') {
  fwrite(STDERR, "FAIL: category not persisted as bebidas\n");
  exit(1);
}

if (($row['subcategory'] ?? '') !== 'cafes') {
  fwrite(STDERR, "FAIL: subcategory not persisted as cafes\n");
  exit(1);
}

echo "PASS\n";
