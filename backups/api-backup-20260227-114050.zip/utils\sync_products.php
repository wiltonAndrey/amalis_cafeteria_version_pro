<?php
/**
 * Bulk sync utility for menu products.
 * Reads JSON from stdin and upserts menu products into MySQL.
 */

$config = require __DIR__ . '/../db_config.php';
require_once __DIR__ . '/menu_taxonomy.php';
require_once __DIR__ . '/menu_categories.php';

function as_string(mixed $value): string
{
    if (is_string($value)) {
        return trim($value);
    }

    if (is_numeric($value)) {
        return trim((string) $value);
    }

    return '';
}

function as_list(mixed $value): array
{
    if (!is_array($value)) {
        return [];
    }

    $items = [];
    foreach ($value as $item) {
        $text = as_string($item);
        if ($text !== '') {
            $items[] = $text;
        }
    }

    return array_values($items);
}

function as_bool_int(mixed $value, int $default = 0): int
{
    if ($value === null) {
        return $default;
    }

    if (is_bool($value)) {
        return $value ? 1 : 0;
    }

    if (is_numeric($value)) {
        return ((int) $value) ? 1 : 0;
    }

    $text = strtolower(as_string($value));
    if ($text === '') {
        return $default;
    }

    return in_array($text, ['1', 'true', 'yes', 'si'], true) ? 1 : 0;
}

function ensure_menu_products_column(PDO $pdo, string $column, string $ddl): void
{
    $stmt = $pdo->prepare(
        'SELECT 1
         FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND COLUMN_NAME = ?
         LIMIT 1'
    );
    $stmt->execute(['menu_products', $column]);

    if (!$stmt->fetchColumn()) {
        $pdo->exec($ddl);
    }
}

function sync_menu_categories(PDO $pdo, array $categories): int
{
    if ($categories === []) {
        return 0;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO menu_categories (id, label, sort_order, active, visible_in_menu)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           label = VALUES(label),
           sort_order = VALUES(sort_order)'
    );
    $count = 0;

    foreach ($categories as $index => $category) {
        if (!is_array($category)) {
            continue;
        }

        $id = as_string($category['id'] ?? '');
        $label = as_string($category['label'] ?? '');
        $sortOrder = isset($category['sort_order']) && is_numeric($category['sort_order'])
            ? (int) $category['sort_order']
            : (int) $index;
        $active = array_key_exists('active', $category)
            ? as_bool_int($category['active'], 1)
            : ($id === 'ofertas' ? 0 : 1);
        $visibleInMenu = array_key_exists('visible_in_menu', $category)
            ? as_bool_int($category['visible_in_menu'], 1)
            : ($id === 'ofertas' ? 0 : 1);
        if ($active === 0) {
            $visibleInMenu = 0;
        }

        if ($id === '' || $label === '') {
            continue;
        }

        $stmt->execute([$id, $label, $sortOrder, $active, $visibleInMenu]);
        $count++;
    }

    return $count;
}

function placeholder_list(int $count): string
{
    return implode(',', array_fill(0, $count, '?'));
}

try {
    $dsn = "mysql:host={$config['host']};dbname={$config['name']};charset=utf8mb4";
    $pdo = new PDO($dsn, $config['user'], $config['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $input = file_get_contents('php://stdin');
    $data = json_decode($input, true);

    if (!is_array($data) || !isset($data['action'])) {
        echo json_encode(['error' => 'invalid_json_or_action'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit(1);
    }

    if ($data['action'] !== 'sync_menu_products') {
        echo json_encode(['error' => 'unsupported_action'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit(1);
    }

    ensure_menu_products_column($pdo, 'alt_text', 'ALTER TABLE menu_products ADD COLUMN alt_text VARCHAR(255) DEFAULT NULL AFTER image');
    ensure_menu_products_column($pdo, 'image_title', 'ALTER TABLE menu_products ADD COLUMN image_title VARCHAR(255) DEFAULT NULL AFTER alt_text');
    ensure_menu_products_column($pdo, 'chef_suggestion', 'ALTER TABLE menu_products ADD COLUMN chef_suggestion TEXT DEFAULT NULL AFTER image_title');
    ensure_menu_products_column($pdo, 'subcategory', 'ALTER TABLE menu_products ADD COLUMN subcategory VARCHAR(32) DEFAULT NULL AFTER category');
    menu_categories_ensure_schema($pdo);

    $products = is_array($data['products'] ?? null) ? $data['products'] : [];
    $categories = is_array($data['menuCategories'] ?? null) ? $data['menuCategories'] : [];
    $deactivateMissing = !empty($data['deactivate_missing']);
    $matchBy = as_string($data['match_by'] ?? 'name_category');
    if (!in_array($matchBy, ['name', 'name_category'], true)) {
        $matchBy = 'name_category';
    }

    $pdo->beginTransaction();

    $syncedCategoryCount = sync_menu_categories($pdo, $categories);

    $findByNameStmt = $pdo->prepare('SELECT id FROM menu_products WHERE name = ? ORDER BY active DESC, id ASC');
    $findByNameCategoryStmt = $pdo->prepare('SELECT id FROM menu_products WHERE name = ? AND category = ? ORDER BY active DESC, id ASC');

    $updateStmt = $pdo->prepare(
        'UPDATE menu_products SET
            name = :name,
            price = :price,
            category = :category,
            subcategory = :subcategory,
            description = :description,
            image = :image,
            alt_text = :alt_text,
            image_title = :image_title,
            chef_suggestion = :chef_suggestion,
            ingredients = :ingredients,
            allergens = :allergens,
            featured = :featured,
            active = :active,
            sort_order = :sort_order
         WHERE id = :id'
    );

    $insertStmt = $pdo->prepare(
        'INSERT INTO menu_products
            (name, price, category, subcategory, description, image, alt_text, image_title, chef_suggestion, ingredients, allergens, featured, active, sort_order)
         VALUES
            (:name, :price, :category, :subcategory, :description, :image, :alt_text, :image_title, :chef_suggestion, :ingredients, :allergens, :featured, :active, :sort_order)'
    );

    $results = [];
    $syncedIds = [];
    $updatedCount = 0;
    $insertedCount = 0;
    $duplicateDeactivatedCount = 0;

    foreach ($products as $index => $product) {
        if (!is_array($product)) {
            continue;
        }

        $name = as_string($product['name'] ?? '');
        $category = as_string($product['category'] ?? '');
        $description = as_string($product['description'] ?? '');
        $image = as_string($product['image'] ?? '');

        if ($name === '' || $category === '' || $description === '' || $image === '') {
            throw new RuntimeException('missing_required_product_fields_at_index_' . $index);
        }

        $price = $product['price'] ?? null;
        if (!is_numeric($price)) {
            throw new RuntimeException('invalid_price_at_index_' . $index);
        }

        $taxonomy = menu_taxonomy_normalize_product_taxonomy($name, $category, $product['subcategory'] ?? null);

        $params = [
            'name' => $name,
            'price' => (float) $price,
            'category' => (string) ($taxonomy['category'] ?? $category),
            'subcategory' => $taxonomy['subcategory'] ?? null,
            'description' => $description,
            'image' => $image,
            'alt_text' => as_string($product['alt_text'] ?? ''),
            'image_title' => as_string($product['image_title'] ?? ''),
            'chef_suggestion' => as_string($product['chef_suggestion'] ?? ''),
            'ingredients' => json_encode(as_list($product['ingredients'] ?? []), JSON_UNESCAPED_UNICODE),
            'allergens' => json_encode(as_list($product['allergens'] ?? []), JSON_UNESCAPED_UNICODE),
            'featured' => as_bool_int($product['featured'] ?? 0),
            'active' => as_bool_int($product['active'] ?? 1, 1),
            'sort_order' => isset($product['sort_order']) && is_numeric($product['sort_order'])
                ? (int) $product['sort_order']
                : ($index + 1),
        ];

        if ($matchBy === 'name') {
            $findByNameStmt->execute([$name]);
            $matches = $findByNameStmt->fetchAll(PDO::FETCH_COLUMN);
        } else {
            $findByNameCategoryStmt->execute([$name, $params['category']]);
            $matches = $findByNameCategoryStmt->fetchAll(PDO::FETCH_COLUMN);
        }

        $matches = array_map('intval', $matches ?: []);
        $existingId = $matches[0] ?? 0;
        $duplicateIds = array_slice($matches, 1);

        if ($duplicateIds !== []) {
            $deactivateDuplicatesSql = 'UPDATE menu_products SET active = 0 WHERE id IN (' . placeholder_list(count($duplicateIds)) . ')';
            $deactivateDuplicatesStmt = $pdo->prepare($deactivateDuplicatesSql);
            $deactivateDuplicatesStmt->execute($duplicateIds);
            $duplicateDeactivatedCount += $deactivateDuplicatesStmt->rowCount();
        }

        if ($existingId > 0) {
            $params['id'] = $existingId;
            $updateStmt->execute($params);
            $syncedIds[] = $existingId;
            $updatedCount++;
            $results[] = 'updated:' . $name;
        } else {
            $insertStmt->execute($params);
            $newId = (int) $pdo->lastInsertId();
            $syncedIds[] = $newId;
            $insertedCount++;
            $results[] = 'inserted:' . $name;
        }
    }

    $deactivatedMissingCount = 0;
    if ($deactivateMissing && $syncedIds !== []) {
        $syncedIds = array_values(array_unique(array_map('intval', $syncedIds)));
        $sql = 'UPDATE menu_products SET active = 0 WHERE active = 1 AND id NOT IN (' . placeholder_list(count($syncedIds)) . ')';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($syncedIds);
        $deactivatedMissingCount = $stmt->rowCount();
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'stats' => [
            'categories_synced' => $syncedCategoryCount,
            'products_received' => count($products),
            'updated' => $updatedCount,
            'inserted' => $insertedCount,
            'duplicate_rows_deactivated' => $duplicateDeactivatedCount,
            'missing_rows_deactivated' => $deactivatedMissingCount,
        ],
        'results' => $results,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo json_encode([
        'error' => $e->getMessage(),
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit(1);
}
