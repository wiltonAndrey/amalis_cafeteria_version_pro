<?php
require __DIR__ . '/bootstrap.php';
require __DIR__ . '/promotions/list.php';

try {
  $pdo = get_pdo();
  menu_categories_ensure_schema($pdo);

  $categoriesStmt = $pdo->prepare(
    "SELECT id, label, sort_order, active, visible_in_menu
     FROM menu_categories
     WHERE id = 'all'
        OR (active = 1 AND visible_in_menu = 1)
     ORDER BY CASE WHEN id = 'all' THEN -1 ELSE sort_order END, id"
  );
  $categoriesStmt->execute();
  $categories = $categoriesStmt->fetchAll();

  $menuStmt = $pdo->prepare(
    "SELECT mp.id, mp.name, mp.price, mp.category, mp.subcategory, mp.description, mp.image, mp.alt_text, mp.image_title, mp.chef_suggestion, mp.ingredients, mp.allergens, mp.featured
     FROM menu_products mp
     INNER JOIN menu_categories mc
       ON mc.id = mp.category
      AND mc.active = 1
      AND mc.visible_in_menu = 1
     WHERE mp.active = 1
     ORDER BY mp.sort_order, mp.id"
  );
  $menuStmt->execute();
  $menuRows = $menuStmt->fetchAll();

  $menuProducts = array_map(static function (array $row): array {
    $taxonomy = menu_taxonomy_normalize_product_taxonomy(
      (string) ($row['name'] ?? ''),
      (string) ($row['category'] ?? ''),
      $row['subcategory'] ?? null
    );

    return [
      'id' => (string) $row['id'],
      'name' => $row['name'],
      'price' => (float) $row['price'],
      'category' => $taxonomy['category'],
      'subcategory' => $taxonomy['subcategory'],
      'description' => $row['description'],
      'image' => $row['image'],
      'alt_text' => $row['alt_text'] ?? '',
      'image_title' => $row['image_title'] ?? '',
      'chef_suggestion' => $row['chef_suggestion'] ?? '',
      'ingredients' => json_decode($row['ingredients'], true) ?: [],
      'allergens' => json_decode($row['allergens'], true) ?: [],
      'featured' => (bool) $row['featured'],
    ];
  }, $menuRows);

  $featuredStmt = $pdo->prepare(
    'SELECT id, name, description, price_text, category, image_url, image_alt
     FROM products
     WHERE active = 1
     ORDER BY sort_order, id'
  );
  $featuredStmt->execute();
  $featuredRows = $featuredStmt->fetchAll();

  $featuredProducts = array_map(static function (array $row): array {
    return [
      'id' => (string) $row['id'],
      'name' => $row['name'],
      'description' => $row['description'],
      'price' => $row['price_text'],
      'category' => $row['category'],
      'imageUrl' => $row['image_url'],
      'imageAlt' => $row['image_alt'],
    ];
  }, $featuredRows);

  $payload = [
    'menuCategories' => $categories,
    'menuProducts' => $menuProducts,
    'featuredProducts' => $featuredProducts,
    'promotionCards' => promotions_list_cards($pdo),
  ];

  api_send_cached_json($payload, 90);
} catch (Throwable $error) {
  Response::error('db_error', 500, $error);
}
