<?php
require __DIR__ . '/../bootstrap.php';
require __DIR__ . '/_auth.php';

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'POST') {
  Response::json(['ok' => false, 'error' => 'method_not_allowed'], 405);
  return;
}

if (!api_require_request_guard('auth_login', 10, 60)) {
  return;
}

api_start_session();

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
  $body = [];
}

$email = trim((string) ($body['email'] ?? ''));
$password = (string) ($body['password'] ?? '');

if ($email === '' || $password === '') {
  Response::json(['ok' => false, 'error' => 'missing_credentials'], 400);
  return;
}

$result = login_admin(get_pdo(), $email, $password);
if (!$result['ok']) {
  Response::json(['ok' => false, 'error' => 'invalid_credentials'], 401);
  return;
}

Response::json($result);
