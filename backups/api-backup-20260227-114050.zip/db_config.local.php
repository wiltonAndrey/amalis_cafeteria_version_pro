<?php
return [
  'host' => 'localhost',
  'name' => 'amalis_cms',
  'user' => 'root',
  'pass' => 'wilton78134417J!',
];
