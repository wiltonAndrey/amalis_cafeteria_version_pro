<?php
require_once __DIR__ . '/../bootstrap.php';

function login_admin(PDO $pdo, string $email, string $password): array
{
  api_start_session();

  $stmt = $pdo->prepare('SELECT id, email, password_hash FROM admins WHERE email = ? LIMIT 1');
  $stmt->execute([$email]);
  $admin = $stmt->fetch();

  if (!$admin || !password_verify($password, $admin['password_hash'])) {
    if (function_exists('api_log')) {
      api_log('warning', 'auth_login_failed', ['email' => $email]);
    }
    return ['ok' => false];
  }

  session_regenerate_id(true);
  $_SESSION['admin_id'] = $admin['id'];
  $_SESSION['admin_email'] = $admin['email'];
  $_SESSION['admin_logged_at'] = time();
  if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
  }

  return [
    'ok' => true,
    'admin' => [
      'id' => $admin['id'],
      'email' => $admin['email'],
    ],
    'csrfToken' => $_SESSION['csrf_token'],
  ];
}
