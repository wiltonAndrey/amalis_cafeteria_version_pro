<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

function fail_test(string $message): void
{
  fwrite(STDERR, "FAIL: {$message}\n");
  exit(1);
}

function images_root(): string
{
  $root = realpath(__DIR__ . '/../../public/images');
  if (!is_string($root) || $root === '') {
    fail_test('public/images root missing');
  }

  return $root;
}

function tiny_png_data(): string
{
  $pngData = base64_decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIW2P4z8DwHwAFgwJ/l4Zz5QAAAABJRU5ErkJggg==',
    true
  );

  if (!is_string($pngData) || $pngData === '') {
    fail_test('failed to build png fixture');
  }

  return $pngData;
}

function make_tiny_png_file(string $prefix): string
{
  $file = tempnam(sys_get_temp_dir(), $prefix);
  if (!is_string($file) || $file === '') {
    fail_test('failed to create temp file');
  }

  file_put_contents($file, tiny_png_data());
  return $file;
}

function run_upload_case(array $file, array $post = []): array
{
  $_SESSION['admin_id'] = 1;
  $_POST = $post;
  $_FILES = ['image' => $file];

  ob_start();
  require __DIR__ . '/../upload.php';
  $json = ob_get_clean();

  $data = json_decode($json, true);
  return is_array($data) ? $data : ['ok' => false, 'error' => 'invalid_json'];
}

// Case 1: invalid mime type
$txtFile = tempnam(sys_get_temp_dir(), 'upload-text-');
file_put_contents($txtFile, 'plain text file');
$invalidType = run_upload_case([
  'name' => 'test.txt',
  'type' => 'text/plain',
  'tmp_name' => $txtFile,
  'error' => 0,
  'size' => filesize($txtFile),
]);
@unlink($txtFile);

if (($invalidType['error'] ?? null) !== 'invalid_type') {
  fail_test('expected invalid_type');
}

// Case 2: file too large
$bigFile = tempnam(sys_get_temp_dir(), 'upload-big-');
file_put_contents($bigFile, str_repeat('A', (5 * 1024 * 1024) + 10));
$tooLarge = run_upload_case([
  'name' => 'big.bin',
  'type' => 'application/octet-stream',
  'tmp_name' => $bigFile,
  'error' => 0,
  'size' => filesize($bigFile),
]);
@unlink($bigFile);

if (($tooLarge['error'] ?? null) !== 'file_too_large') {
  fail_test('expected file_too_large');
}

// Case 3: valid png upload
$pngFile = make_tiny_png_file('upload-png-');

$success = run_upload_case([
  'name' => 'test.png',
  'type' => 'image/png',
  'tmp_name' => $pngFile,
  'error' => 0,
  'size' => filesize($pngFile),
]);

if (empty($success['ok']) || empty($success['url'])) {
  @unlink($pngFile);
  fail_test('expected successful upload');
}

$uploadedRelative = (string) $success['url'];
$uploadedAbsolute = images_root() . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . basename($uploadedRelative);
if (is_string($uploadedAbsolute) && file_exists($uploadedAbsolute)) {
  @unlink($uploadedAbsolute);
}

if (strpos($uploadedRelative, '/images/uploads/') !== 0) {
  fail_test('expected default upload URL to remain in /images/uploads/');
}

// Case 4: product upload uses SEO filename in /images/products
$productPng = make_tiny_png_file('upload-product-');
$productUpload = run_upload_case([
  'name' => 'Napolitana Jamón York.PNG',
  'type' => 'image/png',
  'tmp_name' => $productPng,
  'error' => 0,
  'size' => filesize($productPng),
], ['type' => 'product']);

if (empty($productUpload['ok']) || empty($productUpload['url'])) {
  @unlink($productPng);
  fail_test('expected successful product upload');
}

$expectedProductUrl = '/images/products/napolitana-jamon-york.png';
if (($productUpload['url'] ?? null) !== $expectedProductUrl) {
  fail_test('expected SEO sanitized product URL');
}

$productAbsolute = images_root() . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR . 'napolitana-jamon-york.png';
if (!file_exists($productAbsolute)) {
  fail_test('expected product file saved into public/images/products');
}
@unlink($productAbsolute);

// Case 5: product upload collision adds incremental suffix without overwrite
$productsDir = images_root() . DIRECTORY_SEPARATOR . 'products';
if (!is_dir($productsDir) && !mkdir($productsDir, 0775, true) && !is_dir($productsDir)) {
  fail_test('failed to create products directory for collision test');
}

$collisionBase = $productsDir . DIRECTORY_SEPARATOR . 'croissant-mixto.png';
$collisionSecond = $productsDir . DIRECTORY_SEPARATOR . 'croissant-mixto-2.png';
file_put_contents($collisionBase, 'existing-1');
file_put_contents($collisionSecond, 'existing-2');

$collisionPng = make_tiny_png_file('upload-product-collision-');
$collisionUpload = run_upload_case([
  'name' => 'Croissant Mixto.png',
  'type' => 'image/png',
  'tmp_name' => $collisionPng,
  'error' => 0,
  'size' => filesize($collisionPng),
], ['type' => 'product']);

if (empty($collisionUpload['ok']) || empty($collisionUpload['url'])) {
  @unlink($collisionPng);
  @unlink($collisionBase);
  @unlink($collisionSecond);
  fail_test('expected successful collision product upload');
}

$expectedCollisionUrl = '/images/products/croissant-mixto-3.png';
if (($collisionUpload['url'] ?? null) !== $expectedCollisionUrl) {
  @unlink($collisionBase);
  @unlink($collisionSecond);
  fail_test('expected incremental suffix for product filename collision');
}

$collisionThird = $productsDir . DIRECTORY_SEPARATOR . 'croissant-mixto-3.png';
if (!file_exists($collisionThird)) {
  @unlink($collisionBase);
  @unlink($collisionSecond);
  fail_test('expected collision upload stored as -3 file');
}

@unlink($collisionBase);
@unlink($collisionSecond);
@unlink($collisionThird);

echo "PASS\n";
