<?php
require __DIR__ . '/../bootstrap.php';
require __DIR__ . '/_auth.php';

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($method !== 'GET') {
  Response::json(['ok' => false, 'error' => 'method_not_allowed'], 405);
  return;
}

api_start_session();

$result = require_auth();
if (!$result['ok']) {
  return;
}

Response::json($result);
