<?php
$config = require __DIR__ . '/db_config.php';

if (!function_exists('api_env_string')) {
  function api_env_string(string $key, string $default = ''): string
  {
    $value = getenv($key);
    if ($value === false) {
      return $default;
    }

    $trimmed = trim((string) $value);
    return $trimmed === '' ? $default : $trimmed;
  }
}

if (!function_exists('api_request_id')) {
  function api_request_id(): string
  {
    static $requestId = null;
    if ($requestId !== null) {
      return $requestId;
    }

    $incoming = trim((string) ($_SERVER['HTTP_X_REQUEST_ID'] ?? ''));
    if ($incoming !== '' && preg_match('/^[a-zA-Z0-9._:-]{8,128}$/', $incoming) === 1) {
      $requestId = $incoming;
      return $requestId;
    }

    $requestId = bin2hex(random_bytes(12));
    return $requestId;
  }
}

if (!function_exists('api_client_ip')) {
  function api_client_ip(): string
  {
    $ip = trim((string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? ''));
    if ($ip !== '') {
      return $ip;
    }

    $forwarded = trim((string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''));
    if ($forwarded !== '') {
      $parts = explode(',', $forwarded);
      $candidate = trim((string) ($parts[0] ?? ''));
      if ($candidate !== '') {
        return $candidate;
      }
    }

    return trim((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
  }
}

if (!function_exists('api_allowed_origins')) {
  function api_allowed_origins(): array
  {
    static $origins = null;
    if ($origins !== null) {
      return $origins;
    }

    $raw = api_env_string('APP_ALLOWED_ORIGINS', '');
    if ($raw === '') {
      $origins = [];
      return $origins;
    }

    $parsed = array_map('trim', explode(',', $raw));
    $filtered = array_values(array_filter($parsed, static function ($origin): bool {
      return is_string($origin) && $origin !== '';
    }));

    $origins = array_values(array_unique($filtered));
    return $origins;
  }
}

if (!function_exists('api_is_origin_allowed')) {
  function api_is_origin_allowed(string $origin): bool
  {
    $allowed = api_allowed_origins();
    if ($allowed === []) {
      return true;
    }

    return in_array($origin, $allowed, true);
  }
}

if (!function_exists('api_verify_origin')) {
  function api_verify_origin(): bool
  {
    if (php_sapi_name() === 'cli') {
      return true;
    }

    $allowed = api_allowed_origins();
    if ($allowed === []) {
      return true;
    }

    $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($origin !== '') {
      return api_is_origin_allowed($origin);
    }

    $referer = trim((string) ($_SERVER['HTTP_REFERER'] ?? ''));
    if ($referer === '') {
      return true;
    }

    $parts = parse_url($referer);
    if (!is_array($parts) || empty($parts['host']) || empty($parts['scheme'])) {
      return false;
    }

    $port = isset($parts['port']) ? ':' . $parts['port'] : '';
    $refererOrigin = $parts['scheme'] . '://' . $parts['host'] . $port;
    return api_is_origin_allowed($refererOrigin);
  }
}

if (!function_exists('api_log')) {
  function api_log(string $level, string $message, array $context = []): void
  {
    $payload = [
      'timestamp' => gmdate('c'),
      'level' => $level,
      'message' => $message,
      'request_id' => api_request_id(),
      'ip' => api_client_ip(),
    ];

    foreach ($context as $key => $value) {
      if ($value instanceof Throwable) {
        $payload[$key] = [
          'type' => get_class($value),
          'message' => $value->getMessage(),
          'file' => $value->getFile(),
          'line' => $value->getLine(),
        ];
        continue;
      }

      $payload[$key] = $value;
    }

    $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($encoded === false) {
      error_log('[api] log_encoding_failed');
      return;
    }

    error_log('[api] ' . $encoded);
  }
}

if (!function_exists('api_set_default_headers')) {
  function api_set_default_headers(): void
  {
    if (php_sapi_name() === 'cli') {
      return;
    }

    header('Content-Type: application/json; charset=utf-8');
    header('X-Request-Id: ' . api_request_id());
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    $origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
    $allowed = api_allowed_origins();
    if ($allowed === []) {
      header('Access-Control-Allow-Origin: *');
    } elseif ($origin !== '' && api_is_origin_allowed($origin)) {
      header('Access-Control-Allow-Origin: ' . $origin);
      header('Access-Control-Allow-Credentials: true');
      header('Vary: Origin');
    }

    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Request-Id, X-CSRF-Token');
  }
}

if (!function_exists('api_start_session')) {
  function api_start_session(): void
  {
    if (session_status() === PHP_SESSION_ACTIVE) {
      return;
    }

    if (php_sapi_name() !== 'cli' && !headers_sent()) {
      $isSecure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
      $params = session_get_cookie_params();
      $path = is_string($params['path'] ?? null) && $params['path'] !== '' ? $params['path'] : '/';
      $domain = (string) ($params['domain'] ?? '');
      $lifetime = isset($params['lifetime']) ? (int) $params['lifetime'] : 0;
      session_set_cookie_params([
        'lifetime' => $lifetime,
        'path' => $path,
        'domain' => $domain,
        'secure' => $isSecure,
        'httponly' => true,
        'samesite' => 'Lax',
      ]);
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
    session_start();
  }
}

if (!function_exists('api_rate_limit')) {
  function api_rate_limit(string $bucket, int $maxRequests, int $windowSeconds): bool
  {
    $maxRequests = max(1, $maxRequests);
    $windowSeconds = max(1, $windowSeconds);

    $root = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'amalis_api_rate_limits';
    if (!is_dir($root) && !mkdir($root, 0775, true) && !is_dir($root)) {
      return true;
    }

    $key = hash('sha256', $bucket . '|' . api_client_ip());
    $path = $root . DIRECTORY_SEPARATOR . $key . '.json';
    $handle = @fopen($path, 'c+');
    if ($handle === false) {
      return true;
    }

    if (!flock($handle, LOCK_EX)) {
      fclose($handle);
      return true;
    }

    $raw = stream_get_contents($handle);
    $data = json_decode(is_string($raw) ? $raw : '', true);
    $events = [];
    if (is_array($data['events'] ?? null)) {
      $events = array_values(array_filter($data['events'], static function ($value): bool {
        return is_int($value) || (is_string($value) && ctype_digit($value));
      }));
      $events = array_map('intval', $events);
    }

    $now = time();
    $cutoff = $now - $windowSeconds;
    $events = array_values(array_filter($events, static function (int $timestamp) use ($cutoff): bool {
      return $timestamp >= $cutoff;
    }));

    if (count($events) >= $maxRequests) {
      flock($handle, LOCK_UN);
      fclose($handle);
      return false;
    }

    $events[] = $now;
    ftruncate($handle, 0);
    rewind($handle);
    fwrite($handle, json_encode(['events' => $events]));
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);

    return true;
  }
}

if (!function_exists('api_enforce_rate_limit')) {
  function api_enforce_rate_limit(string $bucket, int $maxRequests, int $windowSeconds): bool
  {
    if (php_sapi_name() === 'cli') {
      return true;
    }

    if (api_rate_limit($bucket, $maxRequests, $windowSeconds)) {
      return true;
    }

    Response::json(['ok' => false, 'error' => 'rate_limited'], 429);
    return false;
  }
}

if (!function_exists('api_require_request_guard')) {
  function api_require_request_guard(string $bucket, int $maxRequests, int $windowSeconds): bool
  {
    if (php_sapi_name() === 'cli') {
      return true;
    }

    if (!api_verify_origin()) {
      Response::json(['ok' => false, 'error' => 'invalid_origin'], 403);
      return false;
    }

    return api_enforce_rate_limit($bucket, $maxRequests, $windowSeconds);
  }
}

if (!function_exists('api_send_cached_json')) {
  function api_send_cached_json(array $payload, int $maxAgeSeconds = 120): void
  {
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
      Response::json(['ok' => false, 'error' => 'serialization_error'], 500);
      return;
    }

    if (php_sapi_name() !== 'cli') {
      $etag = '"' . sha1($json) . '"';
      header('Cache-Control: public, max-age=' . max(0, $maxAgeSeconds) . ', stale-while-revalidate=60');
      header('ETag: ' . $etag);

      $ifNoneMatch = trim((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''));
      if ($ifNoneMatch !== '') {
        $tokens = array_map('trim', explode(',', $ifNoneMatch));
        if (in_array('*', $tokens, true) || in_array($etag, $tokens, true)) {
          http_response_code(304);
          exit;
        }
      }
    }

    echo $json;
    if (php_sapi_name() !== 'cli') {
      exit;
    }
  }
}

if (!function_exists('api_ensure_performance_indexes')) {
  function api_ensure_performance_indexes(PDO $pdo): void
  {
    static $ensured = false;
    if ($ensured) {
      return;
    }
    $ensured = true;

    $indexes = [
      [
        'table' => 'menu_products',
        'name' => 'idx_menu_products_active_category_sort',
        'sql' => 'CREATE INDEX idx_menu_products_active_category_sort ON menu_products (active, category, sort_order, id)',
      ],
      [
        'table' => 'menu_categories',
        'name' => 'idx_menu_categories_visible_sort',
        'sql' => 'CREATE INDEX idx_menu_categories_visible_sort ON menu_categories (active, visible_in_menu, sort_order, id)',
      ],
      [
        'table' => 'products',
        'name' => 'idx_products_active_sort',
        'sql' => 'CREATE INDEX idx_products_active_sort ON products (active, sort_order, id)',
      ],
      [
        'table' => 'promotion_cards',
        'name' => 'idx_promotion_cards_active_sort',
        'sql' => 'CREATE INDEX idx_promotion_cards_active_sort ON promotion_cards (active, sort_order, id)',
      ],
      [
        'table' => 'admins',
        'name' => 'idx_admins_email',
        'sql' => 'CREATE INDEX idx_admins_email ON admins (email)',
      ],
    ];

    $existsStmt = $pdo->prepare(
      'SELECT 1
       FROM information_schema.statistics
       WHERE table_schema = DATABASE()
         AND table_name = ?
         AND index_name = ?
       LIMIT 1'
    );

    foreach ($indexes as $index) {
      try {
        $existsStmt->execute([$index['table'], $index['name']]);
        if ($existsStmt->fetchColumn()) {
          continue;
        }

        $pdo->exec($index['sql']);
      } catch (Throwable $error) {
        api_log('warning', 'index_ensure_failed', [
          'table' => $index['table'],
          'index' => $index['name'],
          'exception' => $error,
        ]);
      }
    }
  }
}

if (!function_exists('get_pdo')) {
  function get_pdo(): PDO
  {
    static $pdo = null;
    if ($pdo) {
      return $pdo;
    }

    $config = $GLOBALS['config'] ?? require __DIR__ . '/db_config.php';

    $dsn = sprintf(
      'mysql:host=%s;dbname=%s;charset=utf8mb4',
      $config['host'],
      $config['name']
    );

    $pdo = new PDO($dsn, $config['user'], $config['pass'], [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    api_ensure_performance_indexes($pdo);
    return $pdo;
  }
}

if (php_sapi_name() !== 'cli') {
  api_set_default_headers();

  if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
  }
}

require_once __DIR__ . '/utils/Response.php';
require_once __DIR__ . '/utils/Validator.php';
require_once __DIR__ . '/utils/menu_taxonomy.php';
require_once __DIR__ . '/utils/menu_categories.php';
require_once __DIR__ . '/middleware/Auth.php';
