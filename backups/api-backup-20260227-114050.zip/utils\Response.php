<?php

final class Response
{
  public static function json(array $payload, int $status = 200): void
  {
    if ($status >= 400 && !array_key_exists('requestId', $payload) && function_exists('api_request_id')) {
      $payload['requestId'] = api_request_id();
    }

    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);

    if (php_sapi_name() !== 'cli') {
      exit;
    }
  }

  public static function error(string $error, int $status = 500, ?Throwable $exception = null, array $context = []): void
  {
    if ($exception !== null && function_exists('api_log')) {
      api_log('error', 'api_error_response', [
        'status' => $status,
        'error' => $error,
        'context' => $context,
        'exception' => $exception,
      ]);
    }

    self::json([
      'ok' => false,
      'error' => $error,
    ], $status);
  }
}
