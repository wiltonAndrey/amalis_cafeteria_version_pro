<?php
require __DIR__ . '/bootstrap.php';

try {
  $pdo = get_pdo();
  $stmt = $pdo->prepare('SELECT setting_key, setting_value FROM settings');
  $stmt->execute();
  $rows = $stmt->fetchAll();

  $map = [];
  foreach ($rows as $row) {
    $map[$row['setting_key']] = $row['setting_value'];
  }

  $payload = [
    'seo' => [
      'title' => $map['seo_title'] ?? '',
      'description' => $map['seo_description'] ?? '',
    ],
    'hero' => [
      'title' => $map['hero_title'] ?? '',
      'subtitle' => $map['hero_subtitle'] ?? '',
      'quote' => $map['hero_quote'] ?? '',
    ],
    'contact' => [
      'address' => $map['contact_address'] ?? '',
      'hours' => $map['contact_hours'] ?? '',
    ],
    'social' => [
      'instagram' => $map['social_instagram'] ?? '',
      'facebook' => $map['social_facebook'] ?? '',
      'twitter' => $map['social_twitter'] ?? '',
    ],
  ];

  api_send_cached_json($payload, 180);
} catch (Throwable $error) {
  Response::error('db_error', 500, $error);
}
